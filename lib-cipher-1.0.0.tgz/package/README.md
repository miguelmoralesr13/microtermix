# lib-cipher

A utility library for encryption and decryption operations supporting **ECIES**, **RSA-OAEP**, and **AES-GCM** algorithms.

## Features

- **ECIES**: Elliptic Curve Integrated Encryption Scheme (X25519 + XChaCha20).
- **RSA**: RSA-OAEP with SHA-256 (SHA-1 MGF1).
- **AES**: AES-GCM (256-bit key) with random IV and authentication tag.
- **Universal**: Works in both Node.js and Browser environments.
- **Zero Dependencies (Browser)**: Uses `node-forge` for universal JS compatibility.

## Installation

### From local .tgz file

```bash
npm install ./libs/lib-cipher/cipher-utils-1.0.0.tgz
```

### As a file dependency

```json
{
  "dependencies": {
    "cipher-utils": "file:./libs/lib-cipher"
  }
}
```

## Usage

### General API

```typescript
import { cipherUtils, ICipherKeys, ICipherOptions } from 'cipher-utils';

const data = {
    ssn: '123-45-6789',
    personalInfo: {
        phone: '555-1234'
    }
};

const options: ICipherOptions = {
    algorithm: 'RSA', // 'ECIES' | 'RSA' | 'AES'
    properties: {
        ssn: true,
        personalInfo: {
            phone: true
        }
    }
};

// Encrypt
const encrypted = await cipherUtils(data, keys, options, 'encrypt');

// Decrypt
const decrypted = await cipherUtils(encrypted, keys, options, 'decrypt');
```

### Algorithm Examples

#### ECIES
Uses the `eciesjs` standard configuration (compatible with backend).
- `publicAccess`: Public Key (Base64)
- `privateAccess`: Private Key (Base64)

#### RSA
Uses RSA-OAEP with message digest SHA-256.
- `publicAccess`: PEM Public Key string.
- `privateAccess`: PEM Private Key string.

#### AES
Uses AES-GCM 256.
- `publicAccess`: 256-bit Secret Key (Base64).
- `privateAccess`: Same 256-bit Secret Key (Base64).

### Helper Functions

```typescript
import { encryptData, decryptData } from 'cipher-utils';

const encrypted = await encryptData(data, keys, options);
const decrypted = await decryptData(encrypted, keys, options);
```

## Verification

The library includes a verification script to validate all algorithms locally:

```bash
node verify_refactor.js
```

## Build

```bash
# Install dependencies
npm install

# Build the library
npm run build

# Create .tgz package
npm run pack
```

## License

MIT
